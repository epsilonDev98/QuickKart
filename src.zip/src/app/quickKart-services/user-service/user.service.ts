import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { IUser } from '../../quickKart-interfaces/user';
import { catchError } from 'rxjs/operators';
import { ICart } from '../../quickKart-interfaces/cart';
import { ICartProduct } from '../../quickKart-interfaces/CartProduct';

@Injectable({
  providedIn: 'root'
})
export class UserService {
   
  constructor(private _http: HttpClient) { }
  validateCrendentials(id: string, password: string): Observable<string> {
    var userObj: IUser;
    userObj = { EmailId: id, UserPassword: password, Gender: null, RoleId: null, DateOfBirth: null, Address: null };
    return this._http.post<string>('http://localhost:11990/api/user/ValidateUserCredentials', userObj).pipe(catchError(this.errorHandler));


  }
  addProductToCart(productId: string, emailId: string): Observable<boolean> {
    var cartObj: ICart;
    cartObj = { ProductId: productId, EmailId: emailId, Quantity: 1 };
    return this._http.post<boolean>('http://localhost:11990/api/user/AddProductToCart', cartObj).pipe(catchError(this.errorHandler));
  }
  getCartProducts(emailId: string): Observable<ICartProduct[]> {

    let param = "?emailId=" + emailId;

    return this._http.get<ICartProduct[]>('http://localhost:11990/api/user/GetCartProducts' + param).pipe(catchError(this.errorHandler));

  }
  updateCartProduct(emailId: string, productId: string, qty: number): Observable<boolean> {
    var cartObj: ICart;
    cartObj = { ProductId: productId, EmailId: emailId, Quantity: qty };
    return this._http.put<boolean>('http://localhost:11990/api/user/UpdateCartProducts', cartObj).pipe(catchError(this.errorHandler));
  }
  deleteCartProduct(prodId: string, emailId: string): Observable<boolean> {
    var cartObj: ICart;
    cartObj = { ProductId: prodId, EmailId: emailId, Quantity: null };
    let httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }), body: cartObj };
    return this._http.delete<boolean>('http://localhost:11990/api/user/DeleteCartProduct', httpOptions).pipe(catchError(this.errorHandler));
  }


  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  } 
}
