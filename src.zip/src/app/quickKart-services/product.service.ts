import { Injectable } from '@angular/core';
import { IProduct } from '../quickKart-interfaces/product';
import { ICategory } from '../quickKart-interfaces/category';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
  products: IProduct[];
  categories: ICategory[];
  constructor(private _http: HttpClient) { }
  getProducts(): Observable<IProduct[]> {
    return this._http.get<IProduct[]>('http://localhost:11990/api/Product/GetProducts').pipe(catchError(this.errorHandler));

    //this.products = [{ "ProductId": "P001", "ProductName": "Lamborghini", "CategoryId": 1, "Price": 18000000, "QuantityAvailable": 10 },
    //{ "ProductId": "P002", "ProductName": "Ben Sherman Mens", "CategoryId": 2, "Price": 1847, "QuantityAvailable": 20 },
    //{ "ProductId": "P003", "ProductName": "BMW Z4", "CategoryId": 1, "Price": 6890000, "QuantityAvailable": 10 },
    //{ "ProductId": "P004", "ProductName": "Samsung ", "CategoryId": 3, "Price": 33800, "QuantityAvailable": 100 },
    //{ "ProductId": "P005", "ProductName": "Lenevo ", "CategoryId": 2, "Price": 33800, "QuantityAvailable": 100 }

    //]
    //return this.products;
  }


    getProductCategories(): Observable < ICategory[] > {
      let tempVar = this._http.get<ICategory[]>('http://localhost:11990/api/Category/GetCategories').pipe(catchError(this.errorHandler));
      return tempVar;
    }
  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error");
  } 
    //this.categories = [
    //  { "CategoryId": 1, "CategoryName": "Motors" },
    //  { "CategoryId": 2, "CategoryName": "Fashion" },
    //  { "CategoryId": 3, "CategoryName": "Electronics" }
    //]
    //return this.categories;
  }

 

