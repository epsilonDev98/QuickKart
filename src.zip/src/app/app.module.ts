import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ViewProductsComponent } from './view-products/view-products.component';
import { LoginComponent } from './login/login.component';
import { ProductService } from './quickKart-services/product.service';
import { HttpClientModule } from '@angular/common/http';
import { CommonLayoutComponent } from './common-layout/common-layout.component';
import { HomeComponent } from './home/home.component';
import { routing } from './app.routing';
import { CustomerLayoutComponent } from './layouts/customer-layout/customer-layout.component';
import { UpdateCartComponent } from './update-cart/update-cart.component';
import { ViewCartComponent } from './view-cart/view-cart.component';
@NgModule({
  declarations: [
    AppComponent,
    ViewProductsComponent,
    LoginComponent,
    CommonLayoutComponent,
    HomeComponent,
    CustomerLayoutComponent,
    UpdateCartComponent,
    ViewCartComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    routing
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
