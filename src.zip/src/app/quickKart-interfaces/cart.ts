export interface ICart {
    ProductId: string,
    EmailId: string,
    Quantity:number
}
